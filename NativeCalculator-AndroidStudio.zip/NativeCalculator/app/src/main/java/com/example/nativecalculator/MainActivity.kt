package com.example.nativecalculator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

class MainActivity : Activity() {
    private lateinit var expressionView: TextView
    private lateinit var resultView: TextView
    private var expression = ""
    private var justEvaluated = false
    private val operatorSet = setOf('+', '−', '×', '÷')

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 18, 28)
        window.navigationBarColor = Color.rgb(15, 18, 28)
        window.decorView.systemUiVisibility = 0
        buildUi()
        render()
    }

    private fun buildUi() {
        val bg = Color.rgb(15, 18, 28)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(18))
            setBackgroundColor(bg)
        }

        val brand = TextView(this).apply {
            text = "CALCULATOR"
            textSize = 13f
            letterSpacing = 0.18f
            setTextColor(Color.rgb(145, 157, 181))
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(34)))

        expressionView = TextView(this).apply {
            textSize = 25f
            gravity = Gravity.BOTTOM or Gravity.END
            setTextColor(Color.rgb(157, 169, 190))
            maxLines = 2
        }
        root.addView(expressionView, LinearLayout.LayoutParams(-1, 0, 1f))

        resultView = TextView(this).apply {
            textSize = 54f
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
        }
        root.addView(resultView, LinearLayout.LayoutParams(-1, dp(100)))

        val keys = arrayOf(
            arrayOf("AC", "⌫", "%", "÷"),
            arrayOf("7", "8", "9", "×"),
            arrayOf("4", "5", "6", "−"),
            arrayOf("1", "2", "3", "+"),
            arrayOf("±", "0", ".", "=")
        )
        val grid = GridLayout(this).apply {
            columnCount = 4
            rowCount = 5
            useDefaultMargins = false
        }
        val gap = dp(9)
        keys.forEachIndexed { r, row ->
            row.forEachIndexed { c, label ->
                val button = Button(this).apply {
                    text = label
                    textSize = if (label.length > 1) 17f else 23f
                    isAllCaps = false
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(when {
                        label == "=" -> Color.WHITE
                        label in operatorSet || label in setOf("÷", "×", "%", "±", "⌫") -> Color.rgb(120, 190, 255)
                        label == "AC" -> Color.rgb(255, 139, 139)
                        else -> Color.WHITE
                    })
                    background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = dp(22).toFloat()
                        setColor(when {
                            label == "=" -> Color.rgb(49, 119, 235)
                            label in operatorSet || label in setOf("÷", "×", "%", "±", "⌫", "AC") -> Color.rgb(35, 43, 61)
                            else -> Color.rgb(27, 34, 49)
                        })
                    }
                    minWidth = 0
                    minimumWidth = 0
                    minHeight = 0
                    minimumHeight = 0
                    setPadding(0, 0, 0, 0)
                    stateListAnimator = null
                    setOnClickListener { onKey(label) }
                }
                val params = GridLayout.LayoutParams(
                    GridLayout.spec(r, 1, 1f),
                    GridLayout.spec(c, 1, 1f)
                ).apply {
                    width = 0
                    height = 0
                    setMargins(gap / 2, gap / 2, gap / 2, gap / 2)
                }
                grid.addView(button, params)
            }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 5f))
        setContentView(root)
    }

    private fun onKey(key: String) {
        when (key) {
            "AC" -> { expression = ""; justEvaluated = false }
            "⌫" -> { if (expression.isNotEmpty()) expression = expression.dropLast(1); justEvaluated = false }
            "=" -> {
                try {
                    val value = evaluate(expression)
                    expression = format(value)
                    justEvaluated = true
                } catch (_: Exception) {
                    resultView.text = "Error"
                    return
                }
            }
            "%" -> {
                val number = trailingNumber(expression)
                if (number != null) {
                    val replacement = format(number.divide(BigDecimal("100"), MathContext.DECIMAL128))
                    expression = expression.dropLast(number.toPlainString().length) + replacement
                }
                justEvaluated = false
            }
            "±" -> toggleSign()
            "." -> {
                if (justEvaluated) expression = ""
                justEvaluated = false
                val current = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!current.contains('.')) expression += if (current.isEmpty()) "0." else "."
            }
            "+", "−", "×", "÷" -> {
                if (expression.isNotEmpty()) {
                    if (expression.last() in operatorSet) expression = expression.dropLast(1)
                    expression += key
                }
                justEvaluated = false
            }
            else -> {
                if (justEvaluated) expression = ""
                justEvaluated = false
                expression += key
            }
        }
        render()
    }

    private fun toggleSign() {
        val n = trailingNumber(expression) ?: return
        val replacement = if (n.signum() < 0) format(n.abs()) else "−${format(n)}"
        expression = expression.dropLast(n.toPlainString().length) + replacement
        justEvaluated = false
    }

    private fun trailingNumber(s: String): BigDecimal? {
        val token = s.takeLastWhile { it.isDigit() || it == '.' }
        return token.toBigDecimalOrNull()
    }

    private fun render() {
        expressionView.text = expression
        if (expression.isEmpty()) resultView.text = "0"
        else if (!justEvaluated) {
            resultView.text = try { format(evaluate(expression)) } catch (_: Exception) { " " }
        } else resultView.text = expression
    }

    private fun format(value: BigDecimal): String {
        val rounded = value.round(MathContext(12, RoundingMode.HALF_UP)).stripTrailingZeros()
        return if (rounded.compareTo(BigDecimal.ZERO) == 0) "0" else rounded.toPlainString()
    }

    private fun evaluate(source: String): BigDecimal {
        val s = source.replace('−', '-').replace('×', '*').replace('÷', '/')
        class Parser {
            var i = 0
            fun expression(): BigDecimal {
                var v = term()
                while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                    val op = s[i++]; val rhs = term()
                    v = if (op == '+') v.add(rhs) else v.subtract(rhs)
                }
                return v
            }
            fun term(): BigDecimal {
                var v = factor()
                while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                    val op = s[i++]; val rhs = factor()
                    v = if (op == '*') v.multiply(rhs) else {
                        if (rhs.compareTo(BigDecimal.ZERO) == 0) throw ArithmeticException("Division by zero")
                        v.divide(rhs, MathContext(14, RoundingMode.HALF_UP))
                    }
                }
                return v
            }
            fun factor(): BigDecimal {
                if (i >= s.length) throw IllegalArgumentException()
                if (s[i] == '+') { i++; return factor() }
                if (s[i] == '-') { i++; return factor().negate() }
                val start = i
                var dots = 0
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) {
                    if (s[i] == '.') dots++
                    if (dots > 1) throw IllegalArgumentException()
                    i++
                }
                if (start == i) throw IllegalArgumentException()
                return s.substring(start, i).toBigDecimal()
            }
        }
        if (s.isBlank() || s.last() in "+-*/.") throw IllegalArgumentException()
        val parser = Parser()
        val result = parser.expression()
        if (parser.i != s.length) throw IllegalArgumentException()
        return result
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
