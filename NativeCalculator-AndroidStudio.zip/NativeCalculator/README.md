# Native Calculator (Android)

A lightweight native Android calculator written in Kotlin using Android SDK views.
No third-party libraries are required.

## Open and run
1. Install Android Studio (Hedgehog or newer).
2. Open this `NativeCalculator` folder.
3. Allow Gradle sync. Use JDK 17.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**.

Minimum Android version: Android 6.0 (API 23).

## Features
- Addition, subtraction, multiplication, division
- Live result preview and operator precedence
- Decimal numbers, percentage, sign toggle, backspace, clear
- Division-by-zero and malformed-expression error handling
- Native Android UI; portrait layout

The project source is in `app/src/main/java/com/example/nativecalculator/MainActivity.kt`.

## Build an APK automatically with GitHub Actions
1. Create a new GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and click **Run workflow** (or push to `main`).
4. When the workflow completes, open its run and download the `NativeCalculator-debug-apk` artifact.
5. Extract the artifact; install `app-debug.apk` on your Android phone. You may need to allow installation from your browser or file manager.

This workflow creates a debug APK for testing. A release APK for Play Store distribution should be built and signed with your own private signing key.
